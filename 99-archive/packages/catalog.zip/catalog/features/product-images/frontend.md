<!--
meta:
  title: Catalog / Product Images / Frontend
  owner: Commerce Engineering
  status: active
  last_reviewed: 2026-04-17
  tags: [catalog, product-images, frontend]
-->
> Hub: [[10-modules/catalog/features/product-images/overview]]

# Product Images - Frontend

## Purpose
This file captures **frontend** behavior, screens, and UI integration points for **Product Images**.

## Frontend behavior notes
- admin image uploader and sort UI
- storefront resolves primary image first, then gallery

## Frontend dependency map
- [[10-modules/catalog/features/product-images/overview]] for scope
- [[workflows]] for user flow
- [[permissions]] for access behavior
- [[api]] for contract usage
- [[edge-cases]] for failure state design

## Related features
- [[10-modules/catalog/features/products/overview|Products]]
- [[10-modules/catalog/features/variants/overview|Variants]]

## Recommended reading order
Read after [[10-modules/catalog/features/product-images/overview]], [[workflows]], [[permissions]], and [[api]].
