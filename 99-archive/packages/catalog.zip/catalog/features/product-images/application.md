<!--
meta:
  title: Catalog / Product Images / Application
  owner: Commerce Engineering
  status: active
  last_reviewed: 2026-04-17
  tags: [catalog, product-images, application]
-->
> Hub: [[10-modules/catalog/features/product-images/overview]]

# Product Images - Application

## Purpose
This file documents **use-case orchestration**, **service** responsibilities, and transactional behavior for **Product Images**.

## Main orchestration paths
- upload image
- set primary image
- reorder gallery

## Application-layer notes
- store only metadata and storage key in DB; asset upload should use a controlled storage service

## Dependent files
- [[business-rules]]
- [[data-model]]
- [[api]]
- [[validations]]
- [[backend]]

## Related features
- [[10-modules/catalog/features/products/overview|Products]]
- [[10-modules/catalog/features/variants/overview|Variants]]

## Recommended reading order
Read after [[business-rules]] and [[data-model]], then before [[api]] and [[backend]].
