<!--
meta:
  title: Catalog / Product Images / Api
  owner: Commerce Engineering
  status: active
  last_reviewed: 2026-04-17
  tags: [catalog, product-images, api]
-->
> Hub: [[10-modules/catalog/features/product-images/overview]]

# Product Images - API

## Purpose
This file lists the likely **API** surface and contract concerns for **Product Images**.

## Endpoints / contract areas
- POST /catalog/products/{productId}/images
- PATCH /catalog/images/{imageId}
- DELETE /catalog/images/{imageId}

## API concerns
- Enforce **tenant** context and role checks.
- Keep request/response contracts aligned with [[data-model]] and [[business-rules]].
- Apply **idempotency** where repeated submit can create duplicate business effects.
- Return errors using the project-wide **error contract** rules.

## Related feature files
- [[10-modules/catalog/features/product-images/overview]]
- [[application]]
- [[permissions]]
- [[validations]]
- [[frontend]]

## Related features
- [[10-modules/catalog/features/products/overview|Products]]
- [[10-modules/catalog/features/variants/overview|Variants]]

## Recommended reading order
Read after [[10-modules/catalog/features/product-images/overview]], [[business-rules]], [[data-model]], and [[application]].
