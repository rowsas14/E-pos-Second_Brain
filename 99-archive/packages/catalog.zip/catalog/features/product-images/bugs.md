<!--
meta:
  title: Catalog / Product Images / Bugs
  owner: Commerce Engineering
  status: active
  last_reviewed: 2026-04-17
  tags: [catalog, product-images, bugs]
-->
> Hub: [[10-modules/catalog/features/product-images/overview]]

# Product Images - Bugs

## Purpose
This file tracks known issues, recurring defects, and defect patterns for **Product Images**.

## Current watch list
- watch for gallery order not updating after drag-and-drop reorder

## Usage rule
- Record confirmed recurring defects here.
- Link bug fixes to [[changelog]] after release.
- Use this file during regression testing and production issue analysis.

## Related feature files
- [[10-modules/catalog/features/product-images/overview]]
- [[edge-cases]]
- [[backend]]
- [[frontend]]
- [[changelog]]

## Recommended reading order
Read when fixing defects or verifying regression risk after changes.
