<!--
meta:
  title: Catalog / Product Images / Permissions
  owner: Commerce Engineering
  status: active
  last_reviewed: 2026-04-17
  tags: [catalog, product-images, permissions]
-->
> Hub: [[10-modules/catalog/features/product-images/overview]]

# Product Images - Permissions

## Purpose
This file explains role and permission behavior for **Product Images**.

## Permission behavior
- catalog admin manages product media

## Why permission rules matter
- This project has strict **tenant** isolation.
- Sensitive actions such as discounts, refunds, stock adjustment, and administration should never rely only on hidden buttons.
- **API**, **frontend**, and **workflow** behavior must resolve the same permission logic.

## Related feature files
- [[10-modules/catalog/features/product-images/overview]]
- [[business-rules]]
- [[api]]
- [[frontend]]

## Related features
- [[10-modules/catalog/features/products/overview|Products]]
- [[10-modules/catalog/features/variants/overview|Variants]]

## Recommended reading order
Read after [[10-modules/catalog/features/product-images/overview]] and before exposing [[api]] or [[frontend]] changes.
