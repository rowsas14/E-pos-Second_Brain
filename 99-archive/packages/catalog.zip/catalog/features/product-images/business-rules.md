<!--
meta:
  title: Catalog / Product Images / Business Rules
  owner: Commerce Engineering
  status: active
  last_reviewed: 2026-04-17
  tags: [catalog, product-images, business-rules]
-->
> Hub: [[10-modules/catalog/features/product-images/overview]]

# Product Images - Business Rules

## Purpose
This file captures the business restrictions and commercial intent for the **Product Images** feature inside the **Catalog** module.

## Core rules
- image belongs to a product and optionally to a variant
- only one primary image should exist per product-level or variant-level target
- storage_key points to object storage asset

## Why these rules matter
E-Commerce requires product media, and admin users need a consistent image model for catalog maintenance.

## Related feature files
- [[10-modules/catalog/features/product-images/overview]]
- [[data-model]]
- [[application]]
- [[permissions]]
- [[validations]]

## Related features
- [[10-modules/catalog/features/products/overview|Products]]
- [[10-modules/catalog/features/variants/overview|Variants]]

## Recommended reading order
Read after [[10-modules/catalog/features/product-images/overview]], then before [[application]], [[api]], and [[validations]].
