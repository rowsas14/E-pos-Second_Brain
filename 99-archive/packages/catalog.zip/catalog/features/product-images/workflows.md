<!--
meta:
  title: Catalog / Product Images / Workflows
  owner: Commerce Engineering
  status: active
  last_reviewed: 2026-04-17
  tags: [catalog, product-images, workflows]
-->
> Hub: [[10-modules/catalog/features/product-images/overview]]

# Product Images - Workflows

## Purpose
This file captures the operational **workflow** for **Product Images** across user, system, and integration steps.

## Main workflows
- upload image
- set primary image
- reorder gallery

## Workflow dependencies
- [[business-rules]]
- [[application]]
- [[permissions]]
- [[validations]]
- [[edge-cases]]

## Related features
- [[10-modules/catalog/features/products/overview|Products]]
- [[10-modules/catalog/features/variants/overview|Variants]]

## Recommended reading order
Read after [[10-modules/catalog/features/product-images/overview]] and [[business-rules]]; combine with [[application]] for end-to-end implementation.
