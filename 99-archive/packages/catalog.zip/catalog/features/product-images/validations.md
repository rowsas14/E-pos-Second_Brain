<!--
meta:
  title: Catalog / Product Images / Validations
  owner: Commerce Engineering
  status: active
  last_reviewed: 2026-04-17
  tags: [catalog, product-images, validations]
-->
> Hub: [[10-modules/catalog/features/product-images/overview]]

# Product Images - Validations

## Purpose
This file records input, business, and **workflow** validations for **Product Images**.

## Validation rules
- reject image assignment across tenant boundaries
- ensure primary flag uniqueness per target object

## Validation dependency map
- [[business-rules]] defines the rule intent.
- [[data-model]] defines structural constraints.
- [[application]] decides when validation runs.
- [[api]] exposes validation failures to clients.

## Related features
- [[10-modules/catalog/features/products/overview|Products]]
- [[10-modules/catalog/features/variants/overview|Variants]]

## Recommended reading order
Read after [[business-rules]] and [[data-model]], then before [[api]] and [[backend]].
