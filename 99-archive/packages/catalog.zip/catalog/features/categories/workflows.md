<!--
meta:
  title: Catalog / Categories / Workflows
  owner: Commerce Engineering
  status: active
  last_reviewed: 2026-04-17
  tags: [catalog, categories, workflows]
-->
> Hub: [[10-modules/catalog/features/categories/overview]]

# Categories - Workflows

## Purpose
This file captures the operational **workflow** for **Categories** across user, system, and integration steps.

## Main workflows
- create root category
- create child category
- attach attribute definitions to category

## Workflow dependencies
- [[business-rules]]
- [[application]]
- [[permissions]]
- [[validations]]
- [[edge-cases]]

## Related features
- [[10-modules/catalog/features/attributes/overview|Attributes]]
- [[10-modules/catalog/features/products/overview|Products]]

## Recommended reading order
Read after [[10-modules/catalog/features/categories/overview]] and [[business-rules]]; combine with [[application]] for end-to-end implementation.
