<!--
meta:
  title: Catalog / Categories / Frontend
  owner: Commerce Engineering
  status: active
  last_reviewed: 2026-04-17
  tags: [catalog, categories, frontend]
-->
> Hub: [[10-modules/catalog/features/categories/overview]]

# Categories - Frontend

## Purpose
This file captures **frontend** behavior, screens, and UI integration points for **Categories**.

## Frontend behavior notes
- tree editor in admin
- storefront and admin filters resolve from category hierarchy

## Frontend dependency map
- [[10-modules/catalog/features/categories/overview]] for scope
- [[workflows]] for user flow
- [[permissions]] for access behavior
- [[api]] for contract usage
- [[edge-cases]] for failure state design

## Related features
- [[10-modules/catalog/features/attributes/overview|Attributes]]
- [[10-modules/catalog/features/products/overview|Products]]

## Recommended reading order
Read after [[10-modules/catalog/features/categories/overview]], [[workflows]], [[permissions]], and [[api]].
