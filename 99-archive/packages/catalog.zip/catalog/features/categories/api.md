<!--
meta:
  title: Catalog / Categories / Api
  owner: Commerce Engineering
  status: active
  last_reviewed: 2026-04-17
  tags: [catalog, categories, api]
-->
> Hub: [[10-modules/catalog/features/categories/overview]]

# Categories - API

## Purpose
This file lists the likely **API** surface and contract concerns for **Categories**.

## Endpoints / contract areas
- POST /catalog/categories
- GET /catalog/categories/tree
- PATCH /catalog/categories/{categoryId}

## API concerns
- Enforce **tenant** context and role checks.
- Keep request/response contracts aligned with [[data-model]] and [[business-rules]].
- Apply **idempotency** where repeated submit can create duplicate business effects.
- Return errors using the project-wide **error contract** rules.

## Related feature files
- [[10-modules/catalog/features/categories/overview]]
- [[application]]
- [[permissions]]
- [[validations]]
- [[frontend]]

## Related features
- [[10-modules/catalog/features/attributes/overview|Attributes]]
- [[10-modules/catalog/features/products/overview|Products]]

## Recommended reading order
Read after [[10-modules/catalog/features/categories/overview]], [[business-rules]], [[data-model]], and [[application]].
