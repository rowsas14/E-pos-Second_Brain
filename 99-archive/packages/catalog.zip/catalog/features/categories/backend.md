<!--
meta:
  title: Catalog / Categories / Backend
  owner: Commerce Engineering
  status: active
  last_reviewed: 2026-04-17
  tags: [catalog, categories, backend]
-->
> Hub: [[10-modules/catalog/features/categories/overview]]

# Categories - Backend

## Purpose
This file captures **backend** implementation details for the .NET **Clean Architecture** solution.

## Backend implementation notes
- treat tree operations carefully; use dedicated service for reparent logic

## Expected code areas
- **Domain** model or domain service where core rule belongs
- **Application** service/use case orchestration
- **Infrastructure** persistence and external **integration**
- **Repository**, **validation**, and transaction boundaries aligned to the feature

## Related feature files
- [[10-modules/catalog/features/categories/overview]]
- [[application]]
- [[data-model]]
- [[validations]]
- [[edge-cases]]

## Related features
- [[10-modules/catalog/features/attributes/overview|Attributes]]
- [[10-modules/catalog/features/products/overview|Products]]

## Recommended reading order
Read after [[application]], [[data-model]], and [[validations]].
