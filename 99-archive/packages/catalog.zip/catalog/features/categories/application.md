<!--
meta:
  title: Catalog / Categories / Application
  owner: Commerce Engineering
  status: active
  last_reviewed: 2026-04-17
  tags: [catalog, categories, application]
-->
> Hub: [[10-modules/catalog/features/categories/overview]]

# Categories - Application

## Purpose
This file documents **use-case orchestration**, **service** responsibilities, and transactional behavior for **Categories**.

## Main orchestration paths
- create root category
- create child category
- attach attribute definitions to category

## Application-layer notes
- treat tree operations carefully; use dedicated service for reparent logic

## Dependent files
- [[business-rules]]
- [[data-model]]
- [[api]]
- [[validations]]
- [[backend]]

## Related features
- [[10-modules/catalog/features/attributes/overview|Attributes]]
- [[10-modules/catalog/features/products/overview|Products]]

## Recommended reading order
Read after [[business-rules]] and [[data-model]], then before [[api]] and [[backend]].
