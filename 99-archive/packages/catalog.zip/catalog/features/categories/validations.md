<!--
meta:
  title: Catalog / Categories / Validations
  owner: Commerce Engineering
  status: active
  last_reviewed: 2026-04-17
  tags: [catalog, categories, validations]
-->
> Hub: [[10-modules/catalog/features/categories/overview]]

# Categories - Validations

## Purpose
This file records input, business, and **workflow** validations for **Categories**.

## Validation rules
- reject duplicate slug within tenant
- block cyclic parent relationships
- reject category-attribute mapping across tenants

## Validation dependency map
- [[business-rules]] defines the rule intent.
- [[data-model]] defines structural constraints.
- [[application]] decides when validation runs.
- [[api]] exposes validation failures to clients.

## Related features
- [[10-modules/catalog/features/attributes/overview|Attributes]]
- [[10-modules/catalog/features/products/overview|Products]]

## Recommended reading order
Read after [[business-rules]] and [[data-model]], then before [[api]] and [[backend]].
