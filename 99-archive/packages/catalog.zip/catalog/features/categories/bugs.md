<!--
meta:
  title: Catalog / Categories / Bugs
  owner: Commerce Engineering
  status: active
  last_reviewed: 2026-04-17
  tags: [catalog, categories, bugs]
-->
> Hub: [[10-modules/catalog/features/categories/overview]]

# Categories - Bugs

## Purpose
This file tracks known issues, recurring defects, and defect patterns for **Categories**.

## Current watch list
- watch for stale category breadcrumbs after parent change

## Usage rule
- Record confirmed recurring defects here.
- Link bug fixes to [[changelog]] after release.
- Use this file during regression testing and production issue analysis.

## Related feature files
- [[10-modules/catalog/features/categories/overview]]
- [[edge-cases]]
- [[backend]]
- [[frontend]]
- [[changelog]]

## Recommended reading order
Read when fixing defects or verifying regression risk after changes.
