<!--
meta:
  title: Catalog / Categories / Business Rules
  owner: Commerce Engineering
  status: active
  last_reviewed: 2026-04-17
  tags: [catalog, categories, business-rules]
-->
> Hub: [[10-modules/catalog/features/categories/overview]]

# Categories - Business Rules

## Purpose
This file captures the business restrictions and commercial intent for the **Categories** feature inside the **Catalog** module.

## Core rules
- slug must be unique within tenant
- parent category must belong to same tenant
- sort order and active status drive admin/storefront presentation

## Why these rules matter
Categories support navigation, filtering, reporting, and attribute mapping for structured product setup.

## Related feature files
- [[10-modules/catalog/features/categories/overview]]
- [[data-model]]
- [[application]]
- [[permissions]]
- [[validations]]

## Related features
- [[10-modules/catalog/features/attributes/overview|Attributes]]
- [[10-modules/catalog/features/products/overview|Products]]

## Recommended reading order
Read after [[10-modules/catalog/features/categories/overview]], then before [[application]], [[api]], and [[validations]].
