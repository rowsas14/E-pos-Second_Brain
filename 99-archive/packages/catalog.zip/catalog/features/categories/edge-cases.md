<!--
meta:
  title: Catalog / Categories / Edge Cases
  owner: Commerce Engineering
  status: active
  last_reviewed: 2026-04-17
  tags: [catalog, categories, edge-cases]
-->
> Hub: [[10-modules/catalog/features/categories/overview]]

# Categories - Edge Cases

## Purpose
This file captures uncommon, exception, and failure conditions for **Categories**.

## Edge cases
- category deactivated while products still active under it
- reparenting a category subtree affecting storefront navigation

## Why this matters
These are the scenarios most likely to break a happy-path implementation even when normal **workflow** and **validation** logic look correct.

## Related feature files
- [[10-modules/catalog/features/categories/overview]]
- [[workflows]]
- [[validations]]
- [[bugs]]
- [[backend]]

## Related features
- [[10-modules/catalog/features/attributes/overview|Attributes]]
- [[10-modules/catalog/features/products/overview|Products]]

## Recommended reading order
Read after the core feature files when handling exceptions, bugs, or production incidents.
