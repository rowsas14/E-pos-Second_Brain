<!--
meta:
  title: Catalog / Categories / Permissions
  owner: Commerce Engineering
  status: active
  last_reviewed: 2026-04-17
  tags: [catalog, categories, permissions]
-->
> Hub: [[10-modules/catalog/features/categories/overview]]

# Categories - Permissions

## Purpose
This file explains role and permission behavior for **Categories**.

## Permission behavior
- catalog admin manages category tree

## Why permission rules matter
- This project has strict **tenant** isolation.
- Sensitive actions such as discounts, refunds, stock adjustment, and administration should never rely only on hidden buttons.
- **API**, **frontend**, and **workflow** behavior must resolve the same permission logic.

## Related feature files
- [[10-modules/catalog/features/categories/overview]]
- [[business-rules]]
- [[api]]
- [[frontend]]

## Related features
- [[10-modules/catalog/features/attributes/overview|Attributes]]
- [[10-modules/catalog/features/products/overview|Products]]

## Recommended reading order
Read after [[10-modules/catalog/features/categories/overview]] and before exposing [[api]] or [[frontend]] changes.
