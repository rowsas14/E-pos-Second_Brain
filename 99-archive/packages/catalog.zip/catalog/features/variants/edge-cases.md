<!--
meta:
  title: Catalog / Variants / Edge Cases
  owner: Commerce Engineering
  status: active
  last_reviewed: 2026-04-17
  tags: [catalog, variants, edge-cases]
-->
> Hub: [[10-modules/catalog/features/variants/overview]]

# Variants - Edge Cases

## Purpose
This file captures uncommon, exception, and failure conditions for **Variants**.

## Edge cases
- barcode reused by old imported record
- variant archived while stock still exists

## Why this matters
These are the scenarios most likely to break a happy-path implementation even when normal **workflow** and **validation** logic look correct.

## Related feature files
- [[10-modules/catalog/features/variants/overview]]
- [[workflows]]
- [[validations]]
- [[bugs]]
- [[backend]]

## Related features
- [[10-modules/catalog/features/products/overview|Products]]
- [[10-modules/catalog/features/attributes/overview|Attributes]]
- [[10-modules/inventory/features/stock-ledger/overview|Stock Ledger]]

## Recommended reading order
Read after the core feature files when handling exceptions, bugs, or production incidents.
