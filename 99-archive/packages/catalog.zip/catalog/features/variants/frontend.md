<!--
meta:
  title: Catalog / Variants / Frontend
  owner: Commerce Engineering
  status: active
  last_reviewed: 2026-04-17
  tags: [catalog, variants, frontend]
-->
> Hub: [[10-modules/catalog/features/variants/overview]]

# Variants - Frontend

## Purpose
This file captures **frontend** behavior, screens, and UI integration points for **Variants**.

## Frontend behavior notes
- admin variant grid with SKU, barcode, and selected attributes
- POS search and scan should resolve directly to variant

## Frontend dependency map
- [[10-modules/catalog/features/variants/overview]] for scope
- [[workflows]] for user flow
- [[permissions]] for access behavior
- [[api]] for contract usage
- [[edge-cases]] for failure state design

## Related features
- [[10-modules/catalog/features/products/overview|Products]]
- [[10-modules/catalog/features/attributes/overview|Attributes]]
- [[10-modules/inventory/features/stock-ledger/overview|Stock Ledger]]

## Recommended reading order
Read after [[10-modules/catalog/features/variants/overview]], [[workflows]], [[permissions]], and [[api]].
