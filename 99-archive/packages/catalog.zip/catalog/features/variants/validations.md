<!--
meta:
  title: Catalog / Variants / Validations
  owner: Commerce Engineering
  status: active
  last_reviewed: 2026-04-17
  tags: [catalog, variants, validations]
-->
> Hub: [[10-modules/catalog/features/variants/overview]]

# Variants - Validations

## Purpose
This file records input, business, and **workflow** validations for **Variants**.

## Validation rules
- reject duplicate SKU/barcode within tenant
- ensure attribute values belong to the correct attribute
- validate at least one active variant for sellable products

## Validation dependency map
- [[business-rules]] defines the rule intent.
- [[data-model]] defines structural constraints.
- [[application]] decides when validation runs.
- [[api]] exposes validation failures to clients.

## Related features
- [[10-modules/catalog/features/products/overview|Products]]
- [[10-modules/catalog/features/attributes/overview|Attributes]]
- [[10-modules/inventory/features/stock-ledger/overview|Stock Ledger]]

## Recommended reading order
Read after [[business-rules]] and [[data-model]], then before [[api]] and [[backend]].
