<!--
meta:
  title: Catalog / Variants / Bugs
  owner: Commerce Engineering
  status: active
  last_reviewed: 2026-04-17
  tags: [catalog, variants, bugs]
-->
> Hub: [[10-modules/catalog/features/variants/overview]]

# Variants - Bugs

## Purpose
This file tracks known issues, recurring defects, and defect patterns for **Variants**.

## Current watch list
- watch for POS product lookup returning product root instead of exact variant

## Usage rule
- Record confirmed recurring defects here.
- Link bug fixes to [[changelog]] after release.
- Use this file during regression testing and production issue analysis.

## Related feature files
- [[10-modules/catalog/features/variants/overview]]
- [[edge-cases]]
- [[backend]]
- [[frontend]]
- [[changelog]]

## Recommended reading order
Read when fixing defects or verifying regression risk after changes.
