<!--
meta:
  title: Catalog / Variants / Application
  owner: Commerce Engineering
  status: active
  last_reviewed: 2026-04-17
  tags: [catalog, variants, application]
-->
> Hub: [[10-modules/catalog/features/variants/overview]]

# Variants - Application

## Purpose
This file documents **use-case orchestration**, **service** responsibilities, and transactional behavior for **Variants**.

## Main orchestration paths
- create variant under product
- assign barcode/SKU and attribute values
- activate or archive variant

## Application-layer notes
- variant service sits at the center of pricing, inventory, cart, sale, and order orchestration
- protect variant uniqueness with DB constraints and service checks

## Dependent files
- [[business-rules]]
- [[data-model]]
- [[api]]
- [[validations]]
- [[backend]]

## Related features
- [[10-modules/catalog/features/products/overview|Products]]
- [[10-modules/catalog/features/attributes/overview|Attributes]]
- [[10-modules/inventory/features/stock-ledger/overview|Stock Ledger]]

## Recommended reading order
Read after [[business-rules]] and [[data-model]], then before [[api]] and [[backend]].
