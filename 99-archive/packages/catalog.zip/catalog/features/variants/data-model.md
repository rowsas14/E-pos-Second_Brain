<!--
meta:
  title: Catalog / Variants / Data Model
  owner: Commerce Engineering
  status: active
  last_reviewed: 2026-04-17
  tags: [catalog, variants, data-model]
-->
> Hub: [[10-modules/catalog/features/variants/overview]]

# Variants - Data Model

## Purpose
This file shows the main **entity**, table, and relationship impact for **Variants**.

## Primary entities
- product_variants
- variant_attribute_values

## Data impact
- This feature stores and reads data under strict **tenant** boundaries.
- Downstream **workflow**, **API**, and reporting behavior depends on the entities above.
- Changes here usually affect **validation**, **repository**, and transaction handling.

## Related feature files
- [[10-modules/catalog/features/variants/overview]]
- [[business-rules]]
- [[application]]
- [[api]]
- [[backend]]

## Related features
- [[10-modules/catalog/features/products/overview|Products]]
- [[10-modules/catalog/features/attributes/overview|Attributes]]
- [[10-modules/inventory/features/stock-ledger/overview|Stock Ledger]]

## Recommended reading order
Read after [[10-modules/catalog/features/variants/overview]] and [[business-rules]], then before [[application]] and [[api]].
