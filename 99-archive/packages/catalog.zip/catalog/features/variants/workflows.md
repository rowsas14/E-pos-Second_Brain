<!--
meta:
  title: Catalog / Variants / Workflows
  owner: Commerce Engineering
  status: active
  last_reviewed: 2026-04-17
  tags: [catalog, variants, workflows]
-->
> Hub: [[10-modules/catalog/features/variants/overview]]

# Variants - Workflows

## Purpose
This file captures the operational **workflow** for **Variants** across user, system, and integration steps.

## Main workflows
- create variant under product
- assign barcode/SKU and attribute values
- activate or archive variant

## Workflow dependencies
- [[business-rules]]
- [[application]]
- [[permissions]]
- [[validations]]
- [[edge-cases]]

## Related features
- [[10-modules/catalog/features/products/overview|Products]]
- [[10-modules/catalog/features/attributes/overview|Attributes]]
- [[10-modules/inventory/features/stock-ledger/overview|Stock Ledger]]

## Recommended reading order
Read after [[10-modules/catalog/features/variants/overview]] and [[business-rules]]; combine with [[application]] for end-to-end implementation.
