<!--
meta:
  title: Catalog / Variants / Api
  owner: Commerce Engineering
  status: active
  last_reviewed: 2026-04-17
  tags: [catalog, variants, api]
-->
> Hub: [[10-modules/catalog/features/variants/overview]]

# Variants - API

## Purpose
This file lists the likely **API** surface and contract concerns for **Variants**.

## Endpoints / contract areas
- POST /catalog/products/{productId}/variants
- GET /catalog/variants/{variantId}
- PATCH /catalog/variants/{variantId}

## API concerns
- Enforce **tenant** context and role checks.
- Keep request/response contracts aligned with [[data-model]] and [[business-rules]].
- Apply **idempotency** where repeated submit can create duplicate business effects.
- Return errors using the project-wide **error contract** rules.

## Related feature files
- [[10-modules/catalog/features/variants/overview]]
- [[application]]
- [[permissions]]
- [[validations]]
- [[frontend]]

## Related features
- [[10-modules/catalog/features/products/overview|Products]]
- [[10-modules/catalog/features/attributes/overview|Attributes]]
- [[10-modules/inventory/features/stock-ledger/overview|Stock Ledger]]

## Recommended reading order
Read after [[10-modules/catalog/features/variants/overview]], [[business-rules]], [[data-model]], and [[application]].
