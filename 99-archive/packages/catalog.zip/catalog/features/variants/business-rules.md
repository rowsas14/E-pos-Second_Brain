<!--
meta:
  title: Catalog / Variants / Business Rules
  owner: Commerce Engineering
  status: active
  last_reviewed: 2026-04-17
  tags: [catalog, variants, business-rules]
-->
> Hub: [[10-modules/catalog/features/variants/overview]]

# Variants - Business Rules

## Purpose
This file captures the business restrictions and commercial intent for the **Variants** feature inside the **Catalog** module.

## Core rules
- sku must be unique within tenant
- barcode must be unique within tenant when present
- variant signature should uniquely represent chosen attribute values within a product

## Why these rules matter
The schema and operating model both depend on variant as the transaction unit for POS and E-Commerce.

## Related feature files
- [[10-modules/catalog/features/variants/overview]]
- [[data-model]]
- [[application]]
- [[permissions]]
- [[validations]]

## Related features
- [[10-modules/catalog/features/products/overview|Products]]
- [[10-modules/catalog/features/attributes/overview|Attributes]]
- [[10-modules/inventory/features/stock-ledger/overview|Stock Ledger]]

## Recommended reading order
Read after [[10-modules/catalog/features/variants/overview]], then before [[application]], [[api]], and [[validations]].
