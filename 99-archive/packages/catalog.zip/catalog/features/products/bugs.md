<!--
meta:
  title: Catalog / Products / Bugs
  owner: Commerce Engineering
  status: active
  last_reviewed: 2026-04-17
  tags: [catalog, products, bugs]
-->
> Hub: [[10-modules/catalog/features/products/overview]]

# Products - Bugs

## Purpose
This file tracks known issues, recurring defects, and defect patterns for **Products**.

## Current watch list
- watch for active product saved without a viable variant set during partial import

## Usage rule
- Record confirmed recurring defects here.
- Link bug fixes to [[changelog]] after release.
- Use this file during regression testing and production issue analysis.

## Related feature files
- [[10-modules/catalog/features/products/overview]]
- [[edge-cases]]
- [[backend]]
- [[frontend]]
- [[changelog]]

## Recommended reading order
Read when fixing defects or verifying regression risk after changes.
