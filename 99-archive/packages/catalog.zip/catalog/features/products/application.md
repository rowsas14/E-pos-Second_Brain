<!--
meta:
  title: Catalog / Products / Application
  owner: Commerce Engineering
  status: active
  last_reviewed: 2026-04-17
  tags: [catalog, products, application]
-->
> Hub: [[10-modules/catalog/features/products/overview]]

# Products - Application

## Purpose
This file documents **use-case orchestration**, **service** responsibilities, and transactional behavior for **Products**.

## Main orchestration paths
- create draft product
- activate product after variant and pricing readiness
- archive product without deleting history

## Application-layer notes
- product application service should coordinate category, brand, tax class, and return policy references
- use lifecycle methods for draft/active/archive transitions

## Dependent files
- [[business-rules]]
- [[data-model]]
- [[api]]
- [[validations]]
- [[backend]]

## Related features
- [[10-modules/catalog/features/variants/overview|Variants]]
- [[10-modules/catalog/features/product-images/overview|Product Images]]
- [[10-modules/pricing/features/price-lists/overview|Price Lists]]

## Recommended reading order
Read after [[business-rules]] and [[data-model]], then before [[api]] and [[backend]].
