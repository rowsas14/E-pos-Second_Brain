<!--
meta:
  title: Catalog / Products / Workflows
  owner: Commerce Engineering
  status: active
  last_reviewed: 2026-04-17
  tags: [catalog, products, workflows]
-->
> Hub: [[10-modules/catalog/features/products/overview]]

# Products - Workflows

## Purpose
This file captures the operational **workflow** for **Products** across user, system, and integration steps.

## Main workflows
- create draft product
- activate product after variant and pricing readiness
- archive product without deleting history

## Workflow dependencies
- [[business-rules]]
- [[application]]
- [[permissions]]
- [[validations]]
- [[edge-cases]]

## Related features
- [[10-modules/catalog/features/variants/overview|Variants]]
- [[10-modules/catalog/features/product-images/overview|Product Images]]
- [[10-modules/pricing/features/price-lists/overview|Price Lists]]

## Recommended reading order
Read after [[10-modules/catalog/features/products/overview]] and [[business-rules]]; combine with [[application]] for end-to-end implementation.
