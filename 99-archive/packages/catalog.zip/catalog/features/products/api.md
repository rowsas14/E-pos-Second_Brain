<!--
meta:
  title: Catalog / Products / Api
  owner: Commerce Engineering
  status: active
  last_reviewed: 2026-04-17
  tags: [catalog, products, api]
-->
> Hub: [[10-modules/catalog/features/products/overview]]

# Products - API

## Purpose
This file lists the likely **API** surface and contract concerns for **Products**.

## Endpoints / contract areas
- POST /catalog/products
- GET /catalog/products/{productId}
- PATCH /catalog/products/{productId}

## API concerns
- Enforce **tenant** context and role checks.
- Keep request/response contracts aligned with [[data-model]] and [[business-rules]].
- Apply **idempotency** where repeated submit can create duplicate business effects.
- Return errors using the project-wide **error contract** rules.

## Related feature files
- [[10-modules/catalog/features/products/overview]]
- [[application]]
- [[permissions]]
- [[validations]]
- [[frontend]]

## Related features
- [[10-modules/catalog/features/variants/overview|Variants]]
- [[10-modules/catalog/features/product-images/overview|Product Images]]
- [[10-modules/pricing/features/price-lists/overview|Price Lists]]

## Recommended reading order
Read after [[10-modules/catalog/features/products/overview]], [[business-rules]], [[data-model]], and [[application]].
