<!--
meta:
  title: Catalog / Products / Permissions
  owner: Commerce Engineering
  status: active
  last_reviewed: 2026-04-17
  tags: [catalog, products, permissions]
-->
> Hub: [[10-modules/catalog/features/products/overview]]

# Products - Permissions

## Purpose
This file explains role and permission behavior for **Products**.

## Permission behavior
- catalog admin manages products
- cashiers only read resolved product/variant data

## Why permission rules matter
- This project has strict **tenant** isolation.
- Sensitive actions such as discounts, refunds, stock adjustment, and administration should never rely only on hidden buttons.
- **API**, **frontend**, and **workflow** behavior must resolve the same permission logic.

## Related feature files
- [[10-modules/catalog/features/products/overview]]
- [[business-rules]]
- [[api]]
- [[frontend]]

## Related features
- [[10-modules/catalog/features/variants/overview|Variants]]
- [[10-modules/catalog/features/product-images/overview|Product Images]]
- [[10-modules/pricing/features/price-lists/overview|Price Lists]]

## Recommended reading order
Read after [[10-modules/catalog/features/products/overview]] and before exposing [[api]] or [[frontend]] changes.
