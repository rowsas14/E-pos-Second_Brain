<!--
meta:
  title: Catalog / Products / Frontend
  owner: Commerce Engineering
  status: active
  last_reviewed: 2026-04-17
  tags: [catalog, products, frontend]
-->
> Hub: [[10-modules/catalog/features/products/overview]]

# Products - Frontend

## Purpose
This file captures **frontend** behavior, screens, and UI integration points for **Products**.

## Frontend behavior notes
- admin product form with channel sellability flags
- storefront shows product summary, but checkout adds variant-level item

## Frontend dependency map
- [[10-modules/catalog/features/products/overview]] for scope
- [[workflows]] for user flow
- [[permissions]] for access behavior
- [[api]] for contract usage
- [[edge-cases]] for failure state design

## Related features
- [[10-modules/catalog/features/variants/overview|Variants]]
- [[10-modules/catalog/features/product-images/overview|Product Images]]
- [[10-modules/pricing/features/price-lists/overview|Price Lists]]

## Recommended reading order
Read after [[10-modules/catalog/features/products/overview]], [[workflows]], [[permissions]], and [[api]].
