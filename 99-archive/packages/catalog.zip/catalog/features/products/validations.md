<!--
meta:
  title: Catalog / Products / Validations
  owner: Commerce Engineering
  status: active
  last_reviewed: 2026-04-17
  tags: [catalog, products, validations]
-->
> Hub: [[10-modules/catalog/features/products/overview]]

# Products - Validations

## Purpose
This file records input, business, and **workflow** validations for **Products**.

## Validation rules
- reject duplicate product slug within tenant
- block activation if sellable product has no active variant
- validate tax class and return policy references

## Validation dependency map
- [[business-rules]] defines the rule intent.
- [[data-model]] defines structural constraints.
- [[application]] decides when validation runs.
- [[api]] exposes validation failures to clients.

## Related features
- [[10-modules/catalog/features/variants/overview|Variants]]
- [[10-modules/catalog/features/product-images/overview|Product Images]]
- [[10-modules/pricing/features/price-lists/overview|Price Lists]]

## Recommended reading order
Read after [[business-rules]] and [[data-model]], then before [[api]] and [[backend]].
