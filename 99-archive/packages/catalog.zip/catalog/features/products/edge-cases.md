<!--
meta:
  title: Catalog / Products / Edge Cases
  owner: Commerce Engineering
  status: active
  last_reviewed: 2026-04-17
  tags: [catalog, products, edge-cases]
-->
> Hub: [[10-modules/catalog/features/products/overview]]

# Products - Edge Cases

## Purpose
This file captures uncommon, exception, and failure conditions for **Products**.

## Edge cases
- product active online but not sellable in POS
- service product with no inventory tracking

## Why this matters
These are the scenarios most likely to break a happy-path implementation even when normal **workflow** and **validation** logic look correct.

## Related feature files
- [[10-modules/catalog/features/products/overview]]
- [[workflows]]
- [[validations]]
- [[bugs]]
- [[backend]]

## Related features
- [[10-modules/catalog/features/variants/overview|Variants]]
- [[10-modules/catalog/features/product-images/overview|Product Images]]
- [[10-modules/pricing/features/price-lists/overview|Price Lists]]

## Recommended reading order
Read after the core feature files when handling exceptions, bugs, or production incidents.
