<!--
meta:
  title: Catalog / Products / Business Rules
  owner: Commerce Engineering
  status: active
  last_reviewed: 2026-04-17
  tags: [catalog, products, business-rules]
-->
> Hub: [[10-modules/catalog/features/products/overview]]

# Products - Business Rules

## Purpose
This file captures the business restrictions and commercial intent for the **Products** feature inside the **Catalog** module.

## Core rules
- product status is draft, active, or archived
- product sellability flags can differ between POS and online
- every sellable product must eventually have at least one active variant

## Why these rules matter
Product is the business-facing item definition, while variants remain the sellable transaction unit.

## Related feature files
- [[10-modules/catalog/features/products/overview]]
- [[data-model]]
- [[application]]
- [[permissions]]
- [[validations]]

## Related features
- [[10-modules/catalog/features/variants/overview|Variants]]
- [[10-modules/catalog/features/product-images/overview|Product Images]]
- [[10-modules/pricing/features/price-lists/overview|Price Lists]]

## Recommended reading order
Read after [[10-modules/catalog/features/products/overview]], then before [[application]], [[api]], and [[validations]].
