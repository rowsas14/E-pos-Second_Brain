<!--
meta:
  title: Catalog / Products / Overview
  owner: Commerce Engineering
  status: active
  last_reviewed: 2026-04-17
  tags: [catalog, products, overview]
-->
# Products

## Purpose
Product merchandising root shared by POS and E-Commerce, holding naming, sellability, tax class, and return-policy context.

## Why this feature exists
Product is the business-facing item definition, while variants remain the sellable transaction unit.

## Scope
- create draft product
- activate product after variant and pricing readiness
- archive product without deleting history

## Navigation hub
- [[business-rules]]
- [[data-model]]
- [[application]]
- [[api]]
- [[workflows]]
- [[permissions]]
- [[validations]]
- [[edge-cases]]
- [[bugs]]
- [[changelog]]
- [[backend]]
- [[frontend]]

## Related features
- [[10-modules/catalog/features/variants/overview|Variants]]
- [[10-modules/catalog/features/product-images/overview|Product Images]]
- [[10-modules/pricing/features/price-lists/overview|Price Lists]]

## Work this feature supports
- Product-specific implementation and change planning
- Business-rule clarification before coding
- API, database, backend, and frontend alignment for the same feature
- Bug analysis and controlled change history at feature level

## Recommended reading order
1. [[10-modules/catalog/features/products/overview]]
2. [[business-rules]]
3. [[data-model]]
4. [[application]]
5. [[api]]
6. [[permissions]]
7. [[validations]]
8. [[workflows]]
9. [[edge-cases]]
10. [[backend]]
11. [[frontend]]
12. [[bugs]]
13. [[changelog]]
