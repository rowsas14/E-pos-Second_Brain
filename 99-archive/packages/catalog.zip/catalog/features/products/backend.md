<!--
meta:
  title: Catalog / Products / Backend
  owner: Commerce Engineering
  status: active
  last_reviewed: 2026-04-17
  tags: [catalog, products, backend]
-->
> Hub: [[10-modules/catalog/features/products/overview]]

# Products - Backend

## Purpose
This file captures **backend** implementation details for the .NET **Clean Architecture** solution.

## Backend implementation notes
- product application service should coordinate category, brand, tax class, and return policy references
- use lifecycle methods for draft/active/archive transitions

## Expected code areas
- **Domain** model or domain service where core rule belongs
- **Application** service/use case orchestration
- **Infrastructure** persistence and external **integration**
- **Repository**, **validation**, and transaction boundaries aligned to the feature

## Related feature files
- [[10-modules/catalog/features/products/overview]]
- [[application]]
- [[data-model]]
- [[validations]]
- [[edge-cases]]

## Related features
- [[10-modules/catalog/features/variants/overview|Variants]]
- [[10-modules/catalog/features/product-images/overview|Product Images]]
- [[10-modules/pricing/features/price-lists/overview|Price Lists]]

## Recommended reading order
Read after [[application]], [[data-model]], and [[validations]].
