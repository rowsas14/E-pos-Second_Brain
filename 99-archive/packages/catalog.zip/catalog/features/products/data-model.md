<!--
meta:
  title: Catalog / Products / Data Model
  owner: Commerce Engineering
  status: active
  last_reviewed: 2026-04-17
  tags: [catalog, products, data-model]
-->
> Hub: [[10-modules/catalog/features/products/overview]]

# Products - Data Model

## Purpose
This file shows the main **entity**, table, and relationship impact for **Products**.

## Primary entities
- products
- return_policy_types
- tax_classes

## Data impact
- This feature stores and reads data under strict **tenant** boundaries.
- Downstream **workflow**, **API**, and reporting behavior depends on the entities above.
- Changes here usually affect **validation**, **repository**, and transaction handling.

## Related feature files
- [[10-modules/catalog/features/products/overview]]
- [[business-rules]]
- [[application]]
- [[api]]
- [[backend]]

## Related features
- [[10-modules/catalog/features/variants/overview|Variants]]
- [[10-modules/catalog/features/product-images/overview|Product Images]]
- [[10-modules/pricing/features/price-lists/overview|Price Lists]]

## Recommended reading order
Read after [[10-modules/catalog/features/products/overview]] and [[business-rules]], then before [[application]] and [[api]].
