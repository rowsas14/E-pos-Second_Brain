<!--
meta:
  title: Catalog / Attributes / Frontend
  owner: Commerce Engineering
  status: active
  last_reviewed: 2026-04-17
  tags: [catalog, attributes, frontend]
-->
> Hub: [[10-modules/catalog/features/attributes/overview]]

# Attributes - Frontend

## Purpose
This file captures **frontend** behavior, screens, and UI integration points for **Attributes**.

## Frontend behavior notes
- admin screens for attribute master, values, and category mapping
- dynamic product form fields should resolve from category mapping

## Frontend dependency map
- [[10-modules/catalog/features/attributes/overview]] for scope
- [[workflows]] for user flow
- [[permissions]] for access behavior
- [[api]] for contract usage
- [[edge-cases]] for failure state design

## Related features
- [[10-modules/catalog/features/categories/overview|Categories]]
- [[10-modules/catalog/features/variants/overview|Variants]]

## Recommended reading order
Read after [[10-modules/catalog/features/attributes/overview]], [[workflows]], [[permissions]], and [[api]].
