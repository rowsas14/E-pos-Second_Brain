<!--
meta:
  title: Catalog / Attributes / Permissions
  owner: Commerce Engineering
  status: active
  last_reviewed: 2026-04-17
  tags: [catalog, attributes, permissions]
-->
> Hub: [[10-modules/catalog/features/attributes/overview]]

# Attributes - Permissions

## Purpose
This file explains role and permission behavior for **Attributes**.

## Permission behavior
- catalog admin manages attributes

## Why permission rules matter
- This project has strict **tenant** isolation.
- Sensitive actions such as discounts, refunds, stock adjustment, and administration should never rely only on hidden buttons.
- **API**, **frontend**, and **workflow** behavior must resolve the same permission logic.

## Related feature files
- [[10-modules/catalog/features/attributes/overview]]
- [[business-rules]]
- [[api]]
- [[frontend]]

## Related features
- [[10-modules/catalog/features/categories/overview|Categories]]
- [[10-modules/catalog/features/variants/overview|Variants]]

## Recommended reading order
Read after [[10-modules/catalog/features/attributes/overview]] and before exposing [[api]] or [[frontend]] changes.
