<!--
meta:
  title: Catalog / Attributes / Api
  owner: Commerce Engineering
  status: active
  last_reviewed: 2026-04-17
  tags: [catalog, attributes, api]
-->
> Hub: [[10-modules/catalog/features/attributes/overview]]

# Attributes - API

## Purpose
This file lists the likely **API** surface and contract concerns for **Attributes**.

## Endpoints / contract areas
- POST /catalog/attributes
- POST /catalog/attributes/{attributeId}/values
- POST /catalog/categories/{categoryId}/attributes

## API concerns
- Enforce **tenant** context and role checks.
- Keep request/response contracts aligned with [[data-model]] and [[business-rules]].
- Apply **idempotency** where repeated submit can create duplicate business effects.
- Return errors using the project-wide **error contract** rules.

## Related feature files
- [[10-modules/catalog/features/attributes/overview]]
- [[application]]
- [[permissions]]
- [[validations]]
- [[frontend]]

## Related features
- [[10-modules/catalog/features/categories/overview|Categories]]
- [[10-modules/catalog/features/variants/overview|Variants]]

## Recommended reading order
Read after [[10-modules/catalog/features/attributes/overview]], [[business-rules]], [[data-model]], and [[application]].
