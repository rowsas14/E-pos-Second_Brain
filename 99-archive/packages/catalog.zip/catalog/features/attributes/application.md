<!--
meta:
  title: Catalog / Attributes / Application
  owner: Commerce Engineering
  status: active
  last_reviewed: 2026-04-17
  tags: [catalog, attributes, application]
-->
> Hub: [[10-modules/catalog/features/attributes/overview]]

# Attributes - Application

## Purpose
This file documents **use-case orchestration**, **service** responsibilities, and transactional behavior for **Attributes**.

## Main orchestration paths
- create attribute definition
- create allowed values
- map attribute to category

## Application-layer notes
- attribute changes can have downstream impact on variant maintenance; use application layer rules, not ad-hoc controller logic

## Dependent files
- [[business-rules]]
- [[data-model]]
- [[api]]
- [[validations]]
- [[backend]]

## Related features
- [[10-modules/catalog/features/categories/overview|Categories]]
- [[10-modules/catalog/features/variants/overview|Variants]]

## Recommended reading order
Read after [[business-rules]] and [[data-model]], then before [[api]] and [[backend]].
