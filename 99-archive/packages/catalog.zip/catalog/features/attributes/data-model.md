<!--
meta:
  title: Catalog / Attributes / Data Model
  owner: Commerce Engineering
  status: active
  last_reviewed: 2026-04-17
  tags: [catalog, attributes, data-model]
-->
> Hub: [[10-modules/catalog/features/attributes/overview]]

# Attributes - Data Model

## Purpose
This file shows the main **entity**, table, and relationship impact for **Attributes**.

## Primary entities
- product_attributes
- attribute_values
- category_attributes

## Data impact
- This feature stores and reads data under strict **tenant** boundaries.
- Downstream **workflow**, **API**, and reporting behavior depends on the entities above.
- Changes here usually affect **validation**, **repository**, and transaction handling.

## Related feature files
- [[10-modules/catalog/features/attributes/overview]]
- [[business-rules]]
- [[application]]
- [[api]]
- [[backend]]

## Related features
- [[10-modules/catalog/features/categories/overview|Categories]]
- [[10-modules/catalog/features/variants/overview|Variants]]

## Recommended reading order
Read after [[10-modules/catalog/features/attributes/overview]] and [[business-rules]], then before [[application]] and [[api]].
