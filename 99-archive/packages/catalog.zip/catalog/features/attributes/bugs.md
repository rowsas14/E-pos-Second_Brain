<!--
meta:
  title: Catalog / Attributes / Bugs
  owner: Commerce Engineering
  status: active
  last_reviewed: 2026-04-17
  tags: [catalog, attributes, bugs]
-->
> Hub: [[10-modules/catalog/features/attributes/overview]]

# Attributes - Bugs

## Purpose
This file tracks known issues, recurring defects, and defect patterns for **Attributes**.

## Current watch list
- watch for legacy imports bypassing allowed value validation

## Usage rule
- Record confirmed recurring defects here.
- Link bug fixes to [[changelog]] after release.
- Use this file during regression testing and production issue analysis.

## Related feature files
- [[10-modules/catalog/features/attributes/overview]]
- [[edge-cases]]
- [[backend]]
- [[frontend]]
- [[changelog]]

## Recommended reading order
Read when fixing defects or verifying regression risk after changes.
