<!--
meta:
  title: Catalog / Attributes / Workflows
  owner: Commerce Engineering
  status: active
  last_reviewed: 2026-04-17
  tags: [catalog, attributes, workflows]
-->
> Hub: [[10-modules/catalog/features/attributes/overview]]

# Attributes - Workflows

## Purpose
This file captures the operational **workflow** for **Attributes** across user, system, and integration steps.

## Main workflows
- create attribute definition
- create allowed values
- map attribute to category

## Workflow dependencies
- [[business-rules]]
- [[application]]
- [[permissions]]
- [[validations]]
- [[edge-cases]]

## Related features
- [[10-modules/catalog/features/categories/overview|Categories]]
- [[10-modules/catalog/features/variants/overview|Variants]]

## Recommended reading order
Read after [[10-modules/catalog/features/attributes/overview]] and [[business-rules]]; combine with [[application]] for end-to-end implementation.
