<!--
meta:
  title: Catalog / Attributes / Validations
  owner: Commerce Engineering
  status: active
  last_reviewed: 2026-04-17
  tags: [catalog, attributes, validations]
-->
> Hub: [[10-modules/catalog/features/attributes/overview]]

# Attributes - Validations

## Purpose
This file records input, business, and **workflow** validations for **Attributes**.

## Validation rules
- reject duplicate attribute code per tenant
- ensure category and attribute share tenant
- ensure selected attribute values match attribute data type

## Validation dependency map
- [[business-rules]] defines the rule intent.
- [[data-model]] defines structural constraints.
- [[application]] decides when validation runs.
- [[api]] exposes validation failures to clients.

## Related features
- [[10-modules/catalog/features/categories/overview|Categories]]
- [[10-modules/catalog/features/variants/overview|Variants]]

## Recommended reading order
Read after [[business-rules]] and [[data-model]], then before [[api]] and [[backend]].
