<!--
meta:
  title: Catalog / Attributes / Business Rules
  owner: Commerce Engineering
  status: active
  last_reviewed: 2026-04-17
  tags: [catalog, attributes, business-rules]
-->
> Hub: [[10-modules/catalog/features/attributes/overview]]

# Attributes - Business Rules

## Purpose
This file captures the business restrictions and commercial intent for the **Attributes** feature inside the **Catalog** module.

## Core rules
- attribute code must be unique within tenant
- select-type attributes can define allowed values
- variant-defining attributes participate in variant signature

## Why these rules matter
Attributes let each tenant define its own product structure without hard-coding category-specific fields.

## Related feature files
- [[10-modules/catalog/features/attributes/overview]]
- [[data-model]]
- [[application]]
- [[permissions]]
- [[validations]]

## Related features
- [[10-modules/catalog/features/categories/overview|Categories]]
- [[10-modules/catalog/features/variants/overview|Variants]]

## Recommended reading order
Read after [[10-modules/catalog/features/attributes/overview]], then before [[application]], [[api]], and [[validations]].
