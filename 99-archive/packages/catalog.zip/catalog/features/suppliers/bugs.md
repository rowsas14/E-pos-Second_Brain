<!--
meta:
  title: Catalog / Suppliers / Bugs
  owner: Commerce Engineering
  status: active
  last_reviewed: 2026-04-17
  tags: [catalog, suppliers, bugs]
-->
> Hub: [[10-modules/catalog/features/suppliers/overview]]

# Suppliers - Bugs

## Purpose
This file tracks known issues, recurring defects, and defect patterns for **Suppliers**.

## Current watch list
- watch for import flows creating duplicate suppliers with spacing/case variation

## Usage rule
- Record confirmed recurring defects here.
- Link bug fixes to [[changelog]] after release.
- Use this file during regression testing and production issue analysis.

## Related feature files
- [[10-modules/catalog/features/suppliers/overview]]
- [[edge-cases]]
- [[backend]]
- [[frontend]]
- [[changelog]]

## Recommended reading order
Read when fixing defects or verifying regression risk after changes.
