<!--
meta:
  title: Catalog / Suppliers / Application
  owner: Commerce Engineering
  status: active
  last_reviewed: 2026-04-17
  tags: [catalog, suppliers, application]
-->
> Hub: [[10-modules/catalog/features/suppliers/overview]]

# Suppliers - Application

## Purpose
This file documents **use-case orchestration**, **service** responsibilities, and transactional behavior for **Suppliers**.

## Main orchestration paths
- create supplier
- maintain supplier addresses
- link product to supplier

## Application-layer notes
- supplier mapping can stay in catalog/inventory boundary without introducing full procurement workflow

## Dependent files
- [[business-rules]]
- [[data-model]]
- [[api]]
- [[validations]]
- [[backend]]

## Related features
- [[10-modules/catalog/features/products/overview|Products]]
- [[10-modules/inventory/features/stock-ledger/overview|Stock Ledger]]

## Recommended reading order
Read after [[business-rules]] and [[data-model]], then before [[api]] and [[backend]].
