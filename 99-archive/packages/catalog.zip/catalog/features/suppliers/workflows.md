<!--
meta:
  title: Catalog / Suppliers / Workflows
  owner: Commerce Engineering
  status: active
  last_reviewed: 2026-04-17
  tags: [catalog, suppliers, workflows]
-->
> Hub: [[10-modules/catalog/features/suppliers/overview]]

# Suppliers - Workflows

## Purpose
This file captures the operational **workflow** for **Suppliers** across user, system, and integration steps.

## Main workflows
- create supplier
- maintain supplier addresses
- link product to supplier

## Workflow dependencies
- [[business-rules]]
- [[application]]
- [[permissions]]
- [[validations]]
- [[edge-cases]]

## Related features
- [[10-modules/catalog/features/products/overview|Products]]
- [[10-modules/inventory/features/stock-ledger/overview|Stock Ledger]]

## Recommended reading order
Read after [[10-modules/catalog/features/suppliers/overview]] and [[business-rules]]; combine with [[application]] for end-to-end implementation.
