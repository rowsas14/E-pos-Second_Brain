<!--
meta:
  title: Catalog / Suppliers / Edge Cases
  owner: Commerce Engineering
  status: active
  last_reviewed: 2026-04-17
  tags: [catalog, suppliers, edge-cases]
-->
> Hub: [[10-modules/catalog/features/suppliers/overview]]

# Suppliers - Edge Cases

## Purpose
This file captures uncommon, exception, and failure conditions for **Suppliers**.

## Edge cases
- multiple suppliers for same product with different lead times
- primary supplier removed while active products still reference it

## Why this matters
These are the scenarios most likely to break a happy-path implementation even when normal **workflow** and **validation** logic look correct.

## Related feature files
- [[10-modules/catalog/features/suppliers/overview]]
- [[workflows]]
- [[validations]]
- [[bugs]]
- [[backend]]

## Related features
- [[10-modules/catalog/features/products/overview|Products]]
- [[10-modules/inventory/features/stock-ledger/overview|Stock Ledger]]

## Recommended reading order
Read after the core feature files when handling exceptions, bugs, or production incidents.
