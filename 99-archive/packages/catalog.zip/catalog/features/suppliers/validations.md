<!--
meta:
  title: Catalog / Suppliers / Validations
  owner: Commerce Engineering
  status: active
  last_reviewed: 2026-04-17
  tags: [catalog, suppliers, validations]
-->
> Hub: [[10-modules/catalog/features/suppliers/overview]]

# Suppliers - Validations

## Purpose
This file records input, business, and **workflow** validations for **Suppliers**.

## Validation rules
- ensure supplier and product share tenant
- enforce primary-address uniqueness

## Validation dependency map
- [[business-rules]] defines the rule intent.
- [[data-model]] defines structural constraints.
- [[application]] decides when validation runs.
- [[api]] exposes validation failures to clients.

## Related features
- [[10-modules/catalog/features/products/overview|Products]]
- [[10-modules/inventory/features/stock-ledger/overview|Stock Ledger]]

## Recommended reading order
Read after [[business-rules]] and [[data-model]], then before [[api]] and [[backend]].
