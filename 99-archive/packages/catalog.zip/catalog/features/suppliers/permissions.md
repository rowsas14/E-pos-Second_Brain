<!--
meta:
  title: Catalog / Suppliers / Permissions
  owner: Commerce Engineering
  status: active
  last_reviewed: 2026-04-17
  tags: [catalog, suppliers, permissions]
-->
> Hub: [[10-modules/catalog/features/suppliers/overview]]

# Suppliers - Permissions

## Purpose
This file explains role and permission behavior for **Suppliers**.

## Permission behavior
- catalog or inventory admin manages suppliers

## Why permission rules matter
- This project has strict **tenant** isolation.
- Sensitive actions such as discounts, refunds, stock adjustment, and administration should never rely only on hidden buttons.
- **API**, **frontend**, and **workflow** behavior must resolve the same permission logic.

## Related feature files
- [[10-modules/catalog/features/suppliers/overview]]
- [[business-rules]]
- [[api]]
- [[frontend]]

## Related features
- [[10-modules/catalog/features/products/overview|Products]]
- [[10-modules/inventory/features/stock-ledger/overview|Stock Ledger]]

## Recommended reading order
Read after [[10-modules/catalog/features/suppliers/overview]] and before exposing [[api]] or [[frontend]] changes.
