<!--
meta:
  title: Catalog / Suppliers / Business Rules
  owner: Commerce Engineering
  status: active
  last_reviewed: 2026-04-17
  tags: [catalog, suppliers, business-rules]
-->
> Hub: [[10-modules/catalog/features/suppliers/overview]]

# Suppliers - Business Rules

## Purpose
This file captures the business restrictions and commercial intent for the **Suppliers** feature inside the **Catalog** module.

## Core rules
- supplier belongs to one tenant
- at most one primary address per supplier
- product-supplier mapping can carry supplier SKU and purchase price

## Why these rules matter
Supplier information supports purchase mapping, onboarding imports, and business traceability even if full procurement is out of MVP.

## Related feature files
- [[10-modules/catalog/features/suppliers/overview]]
- [[data-model]]
- [[application]]
- [[permissions]]
- [[validations]]

## Related features
- [[10-modules/catalog/features/products/overview|Products]]
- [[10-modules/inventory/features/stock-ledger/overview|Stock Ledger]]

## Recommended reading order
Read after [[10-modules/catalog/features/suppliers/overview]], then before [[application]], [[api]], and [[validations]].
