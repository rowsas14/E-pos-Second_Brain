<!--
meta:
  title: Catalog / Suppliers / Frontend
  owner: Commerce Engineering
  status: active
  last_reviewed: 2026-04-17
  tags: [catalog, suppliers, frontend]
-->
> Hub: [[10-modules/catalog/features/suppliers/overview]]

# Suppliers - Frontend

## Purpose
This file captures **frontend** behavior, screens, and UI integration points for **Suppliers**.

## Frontend behavior notes
- admin supplier master screen and product supplier tab

## Frontend dependency map
- [[10-modules/catalog/features/suppliers/overview]] for scope
- [[workflows]] for user flow
- [[permissions]] for access behavior
- [[api]] for contract usage
- [[edge-cases]] for failure state design

## Related features
- [[10-modules/catalog/features/products/overview|Products]]
- [[10-modules/inventory/features/stock-ledger/overview|Stock Ledger]]

## Recommended reading order
Read after [[10-modules/catalog/features/suppliers/overview]], [[workflows]], [[permissions]], and [[api]].
