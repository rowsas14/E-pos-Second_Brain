<!--
meta:
  title: Catalog / Suppliers / Data Model
  owner: Commerce Engineering
  status: active
  last_reviewed: 2026-04-17
  tags: [catalog, suppliers, data-model]
-->
> Hub: [[10-modules/catalog/features/suppliers/overview]]

# Suppliers - Data Model

## Purpose
This file shows the main **entity**, table, and relationship impact for **Suppliers**.

## Primary entities
- suppliers
- supplier_addresses
- product_suppliers

## Data impact
- This feature stores and reads data under strict **tenant** boundaries.
- Downstream **workflow**, **API**, and reporting behavior depends on the entities above.
- Changes here usually affect **validation**, **repository**, and transaction handling.

## Related feature files
- [[10-modules/catalog/features/suppliers/overview]]
- [[business-rules]]
- [[application]]
- [[api]]
- [[backend]]

## Related features
- [[10-modules/catalog/features/products/overview|Products]]
- [[10-modules/inventory/features/stock-ledger/overview|Stock Ledger]]

## Recommended reading order
Read after [[10-modules/catalog/features/suppliers/overview]] and [[business-rules]], then before [[application]] and [[api]].
