<!--
meta:
  title: Catalog / Brands / Workflows
  owner: Commerce Engineering
  status: active
  last_reviewed: 2026-04-17
  tags: [catalog, brands, workflows]
-->
> Hub: [[10-modules/catalog/features/brands/overview]]

# Brands - Workflows

## Purpose
This file captures the operational **workflow** for **Brands** across user, system, and integration steps.

## Main workflows
- create brand
- update brand identity
- deactivate brand no longer used

## Workflow dependencies
- [[business-rules]]
- [[application]]
- [[permissions]]
- [[validations]]
- [[edge-cases]]

## Related features
- [[10-modules/catalog/features/products/overview|Products]]
- [[10-modules/catalog/features/suppliers/overview|Suppliers]]

## Recommended reading order
Read after [[10-modules/catalog/features/brands/overview]] and [[business-rules]]; combine with [[application]] for end-to-end implementation.
