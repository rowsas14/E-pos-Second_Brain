<!--
meta:
  title: Catalog / Brands / Application
  owner: Commerce Engineering
  status: active
  last_reviewed: 2026-04-17
  tags: [catalog, brands, application]
-->
> Hub: [[10-modules/catalog/features/brands/overview]]

# Brands - Application

## Purpose
This file documents **use-case orchestration**, **service** responsibilities, and transactional behavior for **Brands**.

## Main orchestration paths
- create brand
- update brand identity
- deactivate brand no longer used

## Application-layer notes
- simple master data feature; keep service rules around uniqueness and status

## Dependent files
- [[business-rules]]
- [[data-model]]
- [[api]]
- [[validations]]
- [[backend]]

## Related features
- [[10-modules/catalog/features/products/overview|Products]]
- [[10-modules/catalog/features/suppliers/overview|Suppliers]]

## Recommended reading order
Read after [[business-rules]] and [[data-model]], then before [[api]] and [[backend]].
