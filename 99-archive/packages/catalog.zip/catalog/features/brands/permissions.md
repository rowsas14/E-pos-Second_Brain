<!--
meta:
  title: Catalog / Brands / Permissions
  owner: Commerce Engineering
  status: active
  last_reviewed: 2026-04-17
  tags: [catalog, brands, permissions]
-->
> Hub: [[10-modules/catalog/features/brands/overview]]

# Brands - Permissions

## Purpose
This file explains role and permission behavior for **Brands**.

## Permission behavior
- catalog admin manages brands
- cashiers only read resolved brand through product details

## Why permission rules matter
- This project has strict **tenant** isolation.
- Sensitive actions such as discounts, refunds, stock adjustment, and administration should never rely only on hidden buttons.
- **API**, **frontend**, and **workflow** behavior must resolve the same permission logic.

## Related feature files
- [[10-modules/catalog/features/brands/overview]]
- [[business-rules]]
- [[api]]
- [[frontend]]

## Related features
- [[10-modules/catalog/features/products/overview|Products]]
- [[10-modules/catalog/features/suppliers/overview|Suppliers]]

## Recommended reading order
Read after [[10-modules/catalog/features/brands/overview]] and before exposing [[api]] or [[frontend]] changes.
