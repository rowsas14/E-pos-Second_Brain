<!--
meta:
  title: Catalog / Brands / Bugs
  owner: Commerce Engineering
  status: active
  last_reviewed: 2026-04-17
  tags: [catalog, brands, bugs]
-->
> Hub: [[10-modules/catalog/features/brands/overview]]

# Brands - Bugs

## Purpose
This file tracks known issues, recurring defects, and defect patterns for **Brands**.

## Current watch list
- watch for duplicated brand names created through bulk import with case variation

## Usage rule
- Record confirmed recurring defects here.
- Link bug fixes to [[changelog]] after release.
- Use this file during regression testing and production issue analysis.

## Related feature files
- [[10-modules/catalog/features/brands/overview]]
- [[edge-cases]]
- [[backend]]
- [[frontend]]
- [[changelog]]

## Recommended reading order
Read when fixing defects or verifying regression risk after changes.
