<!--
meta:
  title: Catalog / Brands / Data Model
  owner: Commerce Engineering
  status: active
  last_reviewed: 2026-04-17
  tags: [catalog, brands, data-model]
-->
> Hub: [[10-modules/catalog/features/brands/overview]]

# Brands - Data Model

## Purpose
This file shows the main **entity**, table, and relationship impact for **Brands**.

## Primary entities
- brands

## Data impact
- This feature stores and reads data under strict **tenant** boundaries.
- Downstream **workflow**, **API**, and reporting behavior depends on the entities above.
- Changes here usually affect **validation**, **repository**, and transaction handling.

## Related feature files
- [[10-modules/catalog/features/brands/overview]]
- [[business-rules]]
- [[application]]
- [[api]]
- [[backend]]

## Related features
- [[10-modules/catalog/features/products/overview|Products]]
- [[10-modules/catalog/features/suppliers/overview|Suppliers]]

## Recommended reading order
Read after [[10-modules/catalog/features/brands/overview]] and [[business-rules]], then before [[application]] and [[api]].
