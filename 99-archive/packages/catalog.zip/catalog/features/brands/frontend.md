<!--
meta:
  title: Catalog / Brands / Frontend
  owner: Commerce Engineering
  status: active
  last_reviewed: 2026-04-17
  tags: [catalog, brands, frontend]
-->
> Hub: [[10-modules/catalog/features/brands/overview]]

# Brands - Frontend

## Purpose
This file captures **frontend** behavior, screens, and UI integration points for **Brands**.

## Frontend behavior notes
- admin brand list and create/edit drawer
- brand should appear in product filters, not cashier-critical screens

## Frontend dependency map
- [[10-modules/catalog/features/brands/overview]] for scope
- [[workflows]] for user flow
- [[permissions]] for access behavior
- [[api]] for contract usage
- [[edge-cases]] for failure state design

## Related features
- [[10-modules/catalog/features/products/overview|Products]]
- [[10-modules/catalog/features/suppliers/overview|Suppliers]]

## Recommended reading order
Read after [[10-modules/catalog/features/brands/overview]], [[workflows]], [[permissions]], and [[api]].
