<!--
meta:
  title: Catalog / Brands / Validations
  owner: Commerce Engineering
  status: active
  last_reviewed: 2026-04-17
  tags: [catalog, brands, validations]
-->
> Hub: [[10-modules/catalog/features/brands/overview]]

# Brands - Validations

## Purpose
This file records input, business, and **workflow** validations for **Brands**.

## Validation rules
- reject duplicate name or code inside tenant
- normalize brand naming before save

## Validation dependency map
- [[business-rules]] defines the rule intent.
- [[data-model]] defines structural constraints.
- [[application]] decides when validation runs.
- [[api]] exposes validation failures to clients.

## Related features
- [[10-modules/catalog/features/products/overview|Products]]
- [[10-modules/catalog/features/suppliers/overview|Suppliers]]

## Recommended reading order
Read after [[business-rules]] and [[data-model]], then before [[api]] and [[backend]].
