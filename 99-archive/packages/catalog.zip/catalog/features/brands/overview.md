<!--
meta:
  title: Catalog / Brands / Overview
  owner: Commerce Engineering
  status: active
  last_reviewed: 2026-04-17
  tags: [catalog, brands, overview]
-->
# Brands

## Purpose
Tenant-owned brand master used to classify products for both POS and E-Commerce merchandising.

## Why this feature exists
Brand is needed for product organization, search, storefront display, and supplier alignment.

## Scope
- create brand
- update brand identity
- deactivate brand no longer used

## Navigation hub
- [[business-rules]]
- [[data-model]]
- [[application]]
- [[api]]
- [[workflows]]
- [[permissions]]
- [[validations]]
- [[edge-cases]]
- [[bugs]]
- [[changelog]]
- [[backend]]
- [[frontend]]

## Related features
- [[10-modules/catalog/features/products/overview|Products]]
- [[10-modules/catalog/features/suppliers/overview|Suppliers]]

## Work this feature supports
- Product-specific implementation and change planning
- Business-rule clarification before coding
- API, database, backend, and frontend alignment for the same feature
- Bug analysis and controlled change history at feature level

## Recommended reading order
1. [[10-modules/catalog/features/brands/overview]]
2. [[business-rules]]
3. [[data-model]]
4. [[application]]
5. [[api]]
6. [[permissions]]
7. [[validations]]
8. [[workflows]]
9. [[edge-cases]]
10. [[backend]]
11. [[frontend]]
12. [[bugs]]
13. [[changelog]]
