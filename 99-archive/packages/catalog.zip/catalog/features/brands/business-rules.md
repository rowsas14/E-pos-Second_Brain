<!--
meta:
  title: Catalog / Brands / Business Rules
  owner: Commerce Engineering
  status: active
  last_reviewed: 2026-04-17
  tags: [catalog, brands, business-rules]
-->
> Hub: [[10-modules/catalog/features/brands/overview]]

# Brands - Business Rules

## Purpose
This file captures the business restrictions and commercial intent for the **Brands** feature inside the **Catalog** module.

## Core rules
- brand name must be unique within tenant
- optional brand code must be unique within tenant when present
- inactive brand should not be assigned to new active products without override

## Why these rules matter
Brand is needed for product organization, search, storefront display, and supplier alignment.

## Related feature files
- [[10-modules/catalog/features/brands/overview]]
- [[data-model]]
- [[application]]
- [[permissions]]
- [[validations]]

## Related features
- [[10-modules/catalog/features/products/overview|Products]]
- [[10-modules/catalog/features/suppliers/overview|Suppliers]]

## Recommended reading order
Read after [[10-modules/catalog/features/brands/overview]], then before [[application]], [[api]], and [[validations]].
