<!--
meta:
  title: Catalog / Brands / Backend
  owner: Commerce Engineering
  status: active
  last_reviewed: 2026-04-17
  tags: [catalog, brands, backend]
-->
> Hub: [[10-modules/catalog/features/brands/overview]]

# Brands - Backend

## Purpose
This file captures **backend** implementation details for the .NET **Clean Architecture** solution.

## Backend implementation notes
- simple master data feature; keep service rules around uniqueness and status

## Expected code areas
- **Domain** model or domain service where core rule belongs
- **Application** service/use case orchestration
- **Infrastructure** persistence and external **integration**
- **Repository**, **validation**, and transaction boundaries aligned to the feature

## Related feature files
- [[10-modules/catalog/features/brands/overview]]
- [[application]]
- [[data-model]]
- [[validations]]
- [[edge-cases]]

## Related features
- [[10-modules/catalog/features/products/overview|Products]]
- [[10-modules/catalog/features/suppliers/overview|Suppliers]]

## Recommended reading order
Read after [[application]], [[data-model]], and [[validations]].
