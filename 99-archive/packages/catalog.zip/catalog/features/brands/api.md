<!--
meta:
  title: Catalog / Brands / Api
  owner: Commerce Engineering
  status: active
  last_reviewed: 2026-04-17
  tags: [catalog, brands, api]
-->
> Hub: [[10-modules/catalog/features/brands/overview]]

# Brands - API

## Purpose
This file lists the likely **API** surface and contract concerns for **Brands**.

## Endpoints / contract areas
- POST /catalog/brands
- GET /catalog/brands
- PATCH /catalog/brands/{brandId}

## API concerns
- Enforce **tenant** context and role checks.
- Keep request/response contracts aligned with [[data-model]] and [[business-rules]].
- Apply **idempotency** where repeated submit can create duplicate business effects.
- Return errors using the project-wide **error contract** rules.

## Related feature files
- [[10-modules/catalog/features/brands/overview]]
- [[application]]
- [[permissions]]
- [[validations]]
- [[frontend]]

## Related features
- [[10-modules/catalog/features/products/overview|Products]]
- [[10-modules/catalog/features/suppliers/overview|Suppliers]]

## Recommended reading order
Read after [[10-modules/catalog/features/brands/overview]], [[business-rules]], [[data-model]], and [[application]].
